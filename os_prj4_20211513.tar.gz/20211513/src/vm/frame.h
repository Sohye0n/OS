#ifndef Frame
#define Frame
#ifndef __LIB_KERNEL_LIST_H
#include "../lib/kernel/list.h"
#endif
#include "page.h"
#include "swap.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
#include "threads/synch.h"
#include "threads/vaddr.h"

struct frame{
    //physical address
    void* physical_addr;
    //vm_entry
    struct page* vme;
    //list elem
    struct list_elem pelem;
    //to get page directory
    struct thread* thr;
};

void framelist_init(void);
void framelist_insert(struct list* frame_list, struct frame* frame);
void framelist_delete(struct list* frame_list, struct frame* frame);
void page_replace(struct list* frame_list);
void page_delete_func(struct page* pg);
struct list_elem* cur;
#endif Frame