#include "page.h"
#include "threads/vaddr.h"
#include "threads/thread.h"

//return hash_elem's hash value
static unsigned return_hash(const struct hash_elem *e, void *aux){
    //find page (page includes hash_elem e)
    struct page *pg=hash_entry(e,struct page,helem);
    //return hash_elem's hash
    //hash_int->hash_bytes << return hash value
    return hash_int(pg->vaddr);
}

//return vm_entry with smaller vaddr
static bool compare_vaddr(const struct hash_elem *a, const struct hash_elem *b, void *aux){
    //elem 가져오는건 내가 하는거 아니니까 assert 안해도 제대로 가져오겠지...
    struct page* pa=hash_entry(a,struct page,helem);
    struct page* pb=hash_entry(b,struct page,helem);
    //printf("va->vaddr : %p   |   vb->vaddr : %p\n",va->vaddr,vb->vaddr);
    //true if a < b
    return (pa->vaddr<pb->vaddr);
}

void vm_entry_delete_all(struct hash_elem* e,void* aux){
    //find page (page : includes hash_elem e)
    ASSERT(e!=NULL)
    struct page *pg=hash_entry(e,struct page,helem);
    if(pg){
        //if loaded -> free physical memory & free frame mapped with page
        if(pg->is_loaded){
            page_delete_func(pg);
            //clear virtual memory
            pagedir_clear_page(thread_current()->pagedir,pg->vaddr);
            //free page
            free(pg);
        }
        else{
            //free page
            free(pg);
        }
    }
}

//해시테이블을 만들어서 vm에게 할당해줌
void vm_init(struct hash *vm_hash){
    //두번째 인자인 hash 함수로 원소의 해시값을 결정함
    //세번째 인자인 less 함수는 2개의 원소(a,b)의 값을 비교하여 a가 더 작으면 true를 반환함.
    hash_init (vm_hash, return_hash, compare_vaddr, NULL);
}

void vm_clear(struct hash* vm){
    //printf("trying to clear...\n");
    hash_destroy(vm,vm_entry_delete_all);
}

bool vm_insert(struct hash* vm, struct hash_elem* e){
    ASSERT(vm!=NULL); ASSERT(e!=NULL);
    struct hash_elem* try;
    try=hash_insert(vm,e);
    //hash was already full
    if(try==NULL) return true;
    else return false;
}

//해시테이블에서 vaddr을 가진 page를 찾아옴
struct page *search(void* vaddr){
    struct page* real;
    struct hash_elem* hash_elem;

    //page에는 각 페이지의 주소가 있으므로, page_addr을 갖는 page를 찾음
    //page를 찾으려면 list_elem -> hash_elem -> page 순으로 찾아야하는데, hash_elem은 vaddr로만 찾을 수 있다.
    //page에 저장된 vaddr로 hash table의 bucket을 정하고, bucket 내부의 list_elem에 대해 list_elem -> hash_elem -> page를 찾아 page의 vaddr과 처음에 넣어준 vaddr을 비교한다.
    //그래서 찾으려는 page와 같은 vaddr을 가지는 page를 새로 만들어서 얘를 넣어주면 진짜 page를 찾아온다
    mikki.vaddr=pg_round_down(vaddr);
    hash_elem=hash_find(&thread_current()->vm_hash,&mikki.helem);

    //만약 찾는 vaddr에 해당하는 hahs_elem가 없다면 hash_find는 null을 리턴함.
    if(hash_elem==NULL){
        mikki.vaddr=NULL;
        return NULL;
    }
    //찾는 vaddr에 해당하는 hash_elem이 있다면 이를 포함하는 page를 찾아옴.
    else{
        mikki.vaddr=NULL;
        real=hash_entry(hash_elem,struct page,helem);
        return real;
    }
}