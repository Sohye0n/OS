#ifndef Page
#define Page
#ifndef __LIB_KERNEL_HASH_H
#include <hash.h>
#endif

#define BIN 0
#define FILE_VM 1
#define ANONYMOUS 2
#define SWAP 3

/*page나 vm_entry나 비슷한 역할인데 왜 2개를 따로 정의하나? 
>> page replacement를 구현하기 위해.
vm_entry는 프로세스가 사용하는 모든 메모리가 갖고 있음.
page는 이 중 물리 메모리(stack)에 load된 vme만을 가리킴. 
*/

struct mmap_entry {
    int mid;
    struct file* file;
    struct list_elem melem;
    //mmap으로 할당받은 가상 메모리 저장
    //리스트로 관리하는게 더 찾기 빠름
    struct list vme_list;
};

struct page{
    uint8_t type;
    void* vaddr;
    bool writable;
    bool is_loaded;
    //file
    struct file* file;
    size_t file_offset;
    size_t read_bytes;
    size_t zero_bytes;
    //disk swap
    size_t swapidx;
    //mmap으로 연 파일에 해당하는 영역 관리하기 위함
    struct list_elem melem;
    //해시로 빨리 찾기
    struct hash_elem helem;
};

void vm_init(struct hash *vm);
bool vm_insert(struct hash* vm, struct hash_elem* e);
void vm_entry_delete_func(struct hash_elem* e,void* aux);
void vm_clear(struct hash* vm);
//return page with such vaddr
struct page *search(void* vaddr);
//to find some page
struct page mikki;
#endif
