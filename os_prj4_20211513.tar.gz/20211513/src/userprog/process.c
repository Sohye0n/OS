#include "userprog/process.h"
#include <debug.h>
#include <inttypes.h>
#include <round.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "userprog/gdt.h"
#include "userprog/pagedir.h"
#include "userprog/tss.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/flags.h"
#include "threads/init.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "vm/page.h"
#include "vm/frame.h"


static thread_func start_process NO_RETURN;
static bool load (const char *cmdline, void (**eip) (void), void **esp);
void get_filename(const char*, char*);
bool load_to_pmemory(void* vaddr, struct page* pg);
bool load_file_to_page(void* kaddr, struct page* pg);

/* Starts a new thread running a user program loaded from
   FILENAME.  The new thread may be scheduled (and may even exit)
   before process_execute() returns.  Returns the new process's
   thread id, or TID_ERROR if the thread cannot be created. */
tid_t
process_execute (const char *file_name) 
{
  char *fn_copy;
  tid_t tid;
  char file_name_parsed[256];
  get_filename(file_name,file_name_parsed);

  /* Make a copy of FILE_NAME.
     Otherwise there's a race between the caller and load(). */
  fn_copy = palloc_get_page (0);
  if (fn_copy == NULL)
    return TID_ERROR;
  strlcpy (fn_copy, file_name, PGSIZE);
  //printf("1\n");
  //printf("%s\n",file_name_parsed);
  if(filesys_open(file_name_parsed)==NULL){
    return -1;
  }
  //printf("2\n");
  /* Create a new thread to execute FILE_NAME. */
  tid = thread_create (file_name_parsed, PRI_DEFAULT, start_process, fn_copy);
  //printf("process %s executing... pid : %d\n",file_name,tid);  
  if (tid == TID_ERROR)
    palloc_free_page (fn_copy);

  /*로드에 실패한 프로세스는 id가 -1*/
  struct list_elem* index_key=list_begin(&thread_current()->child_list);
  struct list_elem* last_key=list_end(&thread_current()->child_list);
  struct thread* child;
  struct thread* load_fail=NULL;

  //자식 프로세스가 완전히 load 될 때까지 기다리기
  while(1){
    child=list_entry(index_key,struct thread,Iamyourchild);
    //printf("%d  ",child->tid);
    if(child->tid==tid){ //exit_status도 체크하면 무한루프 걸림. 자식load()보다 부모가 먼저 실행될 수도.
      load_fail=child;
      break;
    }
    if(index_key==last_key) break;
    index_key=list_next(index_key);
  }
  //자식 프로세스의 load를 기다리기
  if(load_fail)sema_down(&load_fail->load_lock);

  //load에 실패한 것이 있다면 얘를 완전히 제거해주자
  //process_wait에서 얘의 exit_status인 -1을 리턴해줌.
  if(load_fail->load_success==0){
    return process_wait(tid);
  }

  return tid;
}



/*입력된 문자열에서 파일 이름만 가져오는 함수*/
void get_filename(const char* org, char* result){
  //띄어쓰기 단위로 단어를 분리하면 됨.
  int i=0;
  //파일 이름 뒤에는 널문자나 띄어쓰기가 올 것임.
  while(org[i]!='\0'&&org[i]!=' '){
    result[i]=org[i];
    i++;
  }
  //result의 마지막에도 null을 넣어줘야 함.
  result[i]='\0';
}

//전체 입력의 개수를 리턴한다
int get_arguments(char* org, char** result){
  //공백 단위로 단어를 분리하면 됨.
  //스레드 호출 함수이므로 strtok_r을 사용해야 함.
  char* ret_ptr, *next_ptr;
  int i=0,cnt=0;
  ret_ptr=strtok_r(org," ",&next_ptr);
  while(ret_ptr){
    cnt++;
    result[i++]=ret_ptr;
    ret_ptr=strtok_r(NULL," ",&next_ptr); 
  } 
  //마지막에는 null문자 넣어주기
  result[i]="\0";
  return cnt;
}

// //파싱된 입력을 토대로 스택에 집어넣는다
// void push(char* cmd, void**esp){
//   char** cmd_parsed=malloc(sizeof(char*)*256); //4kb
//   char* cmd_copy=malloc(sizeof(char)*256); //4kb

//   strlcpy(cmd_copy,cmd,strlen(cmd)+1);
//   //printf("%c\n",cmd[1]);
//   int cmd_num=get_arguments(cmd_copy,cmd_parsed);
//   char* esp_copy=*esp;
//   //printf("copy : %p, org : %p\n",esp_copy,*esp);
//   //printf("parsing end. argc : %d\n",cmd_num);
  
//   //명령어들부터 집어넣는다.
//   //오른쪽 끝부터 먼저 들어간다.
//   int tmp,cmd_length=0;
//   for(int i=cmd_num-1; i>=0; i--){
//     tmp=strlen(cmd_parsed[i])+1; //null문자 포함
//     cmd_length+=tmp;
//     *esp=*esp-tmp;
//     strlcpy(*esp,cmd_parsed[i],tmp);
//     //printf("address : %p | token : %s\n",*esp,cmd_parsed[i]);
//   }

//   //집어넣은 명령어의 총 길이가 4의 배수인지 확인한다(워드사이즈 32비트)
//   *esp=*esp-4+(cmd_length%4);
//   //printf("addresss : %p\n",*esp);

//   //명령어들의 주소를 집어넣는다.
//   //null문자부터 먼저 집어넣는다.
//   *esp=*esp-4; 
//   **(uint32_t **)esp=0;
//   //printf("addresss : %p\n",*esp);

//   //4개의 명령어의 주소값을 집어넣는다.
//   for(int i=cmd_num-1; i>=0; i--){
//     *esp=*esp-4;
//     esp_copy-=( strlen(cmd_parsed[i]) + 1 );
//     **(uint32_t **)esp=esp_copy;
//     //printf("addresss : %p | data : %0x\n",*esp,**(uint32_t **)esp);
//   } 
 
//   //argv배열의 주소값을 집어넣는다.
//   *esp-=4;
//   **(uint32_t**)esp=*esp+4;
//   //printf("addresss : %p | data : %0x\n",*esp,**(uint32_t **)esp);

//   //argc를 넣는다
//   *esp-=4;
//   **(uint32_t**)esp=cmd_num;
//   //printf("addresss : %p | data : %d\n",*esp,**(uint32_t **)esp);

//   //return address를 넣어준다.
//   *esp-=4;
//   **(uint32_t **)esp=0;
//   //printf("addresss : %p\n",*esp);

//   //hex_dump(*esp,*esp,100,1);
//   free(cmd_copy);
//   free(cmd_parsed);
//   //hex_dump(*esp,*esp,100,1);
// }



/* A thread function that loads a user process and starts it
   running. */
static void
start_process (void *file_name_)
{
  char *file_name = file_name_;
  struct intr_frame if_;
  bool success;

  /*prj4*/
  //init hashtable
  vm_init(&thread_current()->vm_hash);
  list_init(&thread_current()->mmap_list);

  /* Initialize interrupt frame and load executable. */
  memset (&if_, 0, sizeof if_);
  if_.gs = if_.fs = if_.es = if_.ds = if_.ss = SEL_UDSEG;
  if_.cs = SEL_UCSEG;
  if_.eflags = FLAG_IF | FLAG_MBS;
  success = load (file_name, &if_.eip, &if_.esp); //입력으로 받은 프로그램이 실행 가능한지 체크 후 스택을 할당해줌.
  
  /* If load failed, quit. */
  palloc_free_page (file_name);
  if(!success) thread_current()->load_success=0;
  sema_up(&thread_current()->load_lock);  
  if (!success){ 
    printf("here?\n");
    exit(-1);
  }

  /* Start the user process by simulating a return from an
     interrupt, implemented by intr_exit (in
     threads/intr-stubs.S).  Because intr_exit takes all of its
     arguments on the stack in the form of a `struct intr_frame',
     we just point the stack pointer (%esp) to our stack frame
     and jump to it. */
  asm volatile ("movl %0, %%esp; jmp intr_exit" : : "g" (&if_) : "memory");
  NOT_REACHED ();
}

/* Waits for thread TID to die and returns its exit status.  If
   it was terminated by the kernel (i.e. killed due to an
   exception), returns -1.  If TID is invalid or if it was not a
   child of the calling process, or if process_wait() has already
   been successfully called for the given TID, returns -1
   immediately, without waiting.

   This function will be implemented in problem 2-2.  For now, it
   does nothing. */
int
process_wait (tid_t child_tid) 
{
  // int i;
  // for (i = 0; i < 1000000000; i++);
  // return -1;

  /*prj1에서 추가한 내용*/
  struct thread* mychild; //자식 프로세스를 저장할 포인터
  struct thread* me=thread_current(); //현재 실행 중인 프로세스 = 나
  struct list_elem* mychild_key; //자식 프로세스를 찾아올 키
  struct list_elem* last_key=list_end(&me->child_list);
  int exit_status;
  //printf("process_wait start. I'm %d(%s), waiting for %d\n",me->tid,me->name,child_tid);

  //부모 프로세스의 자식 프로세스 키들을 하나씩 가져옴
  //가져온 자식 프로세스 키를 통해 전체 프로세스 리스트에서 자식 프로세스의 몸통을 가져옴
  //파라미터로 받은 tid와 이 자식프로세스의 tid를 비교.
  mychild_key=list_begin(&me->child_list); //부모 프로세스의 첫번째 자식 프로세스 키
  while(1){
    mychild=list_entry(mychild_key,struct thread,Iamyourchild); //키로 프로세스 몸통 찾기 //부모에서가 아니라 전체 프로세스에서 찾음
    
    if(mychild->tid==child_tid){ //일치한다면
      //printf("1 my tid:%d child tid:%d\n",me->tid,mychild->tid);
      sema_down(&mychild->state); //세마포어 1 줄임 (자식 종료까지 기다림)
      //printf("2 my tid:%d child tid:%d\n",me->tid,mychild->tid);
      list_remove(mychild_key); //자식 리스트에서 제거
      //printf("3 my tid:%d child tid:%d\n",me->tid,mychild->tid);
      exit_status=mychild->exit_status; //자식의 exit_status 저장
      sema_up(&mychild->mem);
      //printf("parent %d process_wait end for child %d\, exit_status : %d\n",me->tid,child_tid,exit_status);
      return exit_status;
    }

    if(mychild_key==last_key) break;
    mychild_key=list_next(mychild_key); //일치하지 않는다면 다음 원소를 탐색
  }

  return -1;
}

/* Free the current process's resources. */
void
process_exit (void)
{
  struct thread *cur = thread_current ();
  uint32_t *pd;

  /* Destroy the current process's page directory and switch back
     to the kernel-only page directory. */
  pd = cur->pagedir;

  //clear mmap entry
  struct list_elem* start=list_begin(&thread_current()->mmap_list);
  struct list_elem* end=list_end(&thread_current()->mmap_list);
  struct list_elem* i,*v;
  struct mmap_entry* mmap_cur;
  struct list_elem* mmap_next;
  
  //search for all mmap_entry in mmap_list
  for(i=start; i!=end; i=mmap_next){
    //0. set next element (because we will delete & free current element)
    mmap_next=list_next(i);
    //1. get current elem's structure
    mmap_cur=list_entry(i,struct mmap_entry,melem);

    //search for all vme_entry in each mmap_entry
    struct list_elem* start_v=list_begin(&mmap_cur->vme_list);
    struct list_elem* end_v=list_end(&mmap_cur->vme_list);
    struct page* pg_cur;
    struct list_elem* pg_next;
    for(v=start_v; v!=end_v; v=pg_next){
      //0. set next element (because we will delete & free current element)
      pg_next=list_next(v);
      //1. get current elem's structure
      pg_cur=list_entry(v,struct page, melem);
      //2. if page is dirty => write it back to disk
      if(pg_cur->is_loaded && pagedir_is_dirty(thread_current()->pagedir,pg_cur->vaddr)){
        file_write_at(pg_cur->file, pg_cur->vaddr, pg_cur->read_bytes, pg_cur->file_offset);
      }
      //3. don't free pg. vm_clear() will free all at once.
      list_remove(&pg_cur->melem);
    }

    //2. delete mmap_entry from mmap_list
    list_remove(&mmap_cur->melem);
    //3. free mmap_entry
    free(mmap_cur);
  }

  lock_acquire(&frame_lock);
  vm_clear(&thread_current()->vm_hash);
  lock_release(&frame_lock);

  if (pd != NULL)
    {

      // clear all vme
      //lock_acquire(&frame_lock);
      
      //lock_release(&frame_lock);

      /* Correct ordering here is crucial.  We must set
         cur->pagedir to NULL before switching page directories,
         so that a timer interrupt can't switch back to the
         process page directory.  We must activate the base page
         directory before destroying the process's page
         directory, or our active page directory will be one
         that's been freed (and cleared). */
      cur->pagedir = NULL;
      pagedir_activate (NULL);
      pagedir_destroy (pd);
      //printf("cur thread : %s, sema up!\n",cur->name); 
    }

    sema_up(&cur->state); 
    sema_down(&cur->mem);
}
/* Sets up the CPU for running user code in the current
   thread.
   This function is called on every context switch. */
void
process_activate (void)
{
  struct thread *t = thread_current ();

  /* Activate thread's page tables. */
  pagedir_activate (t->pagedir);

  /* Set thread's kernel stack for use in processing
     interrupts. */
  tss_update ();
}

/* We load ELF binaries.  The following definitions are taken
   from the ELF specification, [ELF1], more-or-less verbatim.  */

/* ELF types.  See [ELF1] 1-2. */
typedef uint32_t Elf32_Word, Elf32_Addr, Elf32_Off;
typedef uint16_t Elf32_Half;

/* For use with ELF types in printf(). */
#define PE32Wx PRIx32   /* Print Elf32_Word in hexadecimal. */
#define PE32Ax PRIx32   /* Print Elf32_Addr in hexadecimal. */
#define PE32Ox PRIx32   /* Print Elf32_Off in hexadecimal. */
#define PE32Hx PRIx16   /* Print Elf32_Half in hexadecimal. */

/* Executable header.  See [ELF1] 1-4 to 1-8.
   This appears at the very beginning of an ELF binary. */
struct Elf32_Ehdr
  {
    unsigned char e_ident[16];
    Elf32_Half    e_type;
    Elf32_Half    e_machine;
    Elf32_Word    e_version;
    Elf32_Addr    e_entry;
    Elf32_Off     e_phoff;
    Elf32_Off     e_shoff;
    Elf32_Word    e_flags;
    Elf32_Half    e_ehsize;
    Elf32_Half    e_phentsize;
    Elf32_Half    e_phnum;
    Elf32_Half    e_shentsize;
    Elf32_Half    e_shnum;
    Elf32_Half    e_shstrndx;
  };

/* Program header.  See [ELF1] 2-2 to 2-4.
   There are e_phnum of these, starting at file offset e_phoff
   (see [ELF1] 1-6). */
struct Elf32_Phdr
  {
    Elf32_Word p_type;
    Elf32_Off  p_offset;
    Elf32_Addr p_vaddr;
    Elf32_Addr p_paddr;
    Elf32_Word p_filesz;
    Elf32_Word p_memsz;
    Elf32_Word p_flags;
    Elf32_Word p_align;
  };

/* Values for p_type.  See [ELF1] 2-3. */
#define PT_NULL    0            /* Ignore. */
#define PT_LOAD    1            /* Loadable segment. */
#define PT_DYNAMIC 2            /* Dynamic linking info. */
#define PT_INTERP  3            /* Name of dynamic loader. */
#define PT_NOTE    4            /* Auxiliary info. */
#define PT_SHLIB   5            /* Reserved. */
#define PT_PHDR    6            /* Program header table. */
#define PT_STACK   0x6474e551   /* Stack segment. */

/* Flags for p_flags.  See [ELF3] 2-3 and 2-4. */
#define PF_X 1          /* Executable. */
#define PF_W 2          /* Writable. */
#define PF_R 4          /* Readable. */

static bool setup_stack (void **esp);
static bool validate_segment (const struct Elf32_Phdr *, struct file *);
static bool load_segment (struct file *file, off_t ofs, uint8_t *upage,
                          uint32_t read_bytes, uint32_t zero_bytes,
                          bool writable);

/* Loads an ELF executable from FILE_NAME into the current thread.
   Stores the executable's entry point into *EIP
   and its initial stack pointer into *ESP.
   Returns true if successful, false otherwise. */
bool
load (const char *file_name, void (**eip) (void), void **esp) 
{
  struct thread *t = thread_current ();
  struct Elf32_Ehdr ehdr;
  struct file *file = NULL;
  off_t file_ofs;
  bool success = false;
  int i;

  /* Allocate and activate page directory. */
  t->pagedir = pagedir_create ();
  if (t->pagedir == NULL) 
    goto done;
  process_activate ();

  /*파일 이름을 파싱해줌*/
  char parsed_file_name[256]; //스택은 최대 4kb
  get_filename(file_name,parsed_file_name);
  /* Open executable file. */
  file = filesys_open (parsed_file_name);

  //printf("%d %d\n",strlen(file_name),(file_name[12]=='\0'));
  if (file == NULL) 
    {
      printf ("load: %s: open failed\n", file_name);
      goto done; 
    }

  /* Read and verify executable header. */
  if (file_read (file, &ehdr, sizeof ehdr) != sizeof ehdr
      || memcmp (ehdr.e_ident, "\177ELF\1\1\1", 7)
      || ehdr.e_type != 2
      || ehdr.e_machine != 3
      || ehdr.e_version != 1
      || ehdr.e_phentsize != sizeof (struct Elf32_Phdr)
      || ehdr.e_phnum > 1024) 
    {
      printf ("load: %s: error loading executable\n", file_name);
      goto done; 
    }

  /* Read program headers. */
  file_ofs = ehdr.e_phoff;
  for (i = 0; i < ehdr.e_phnum; i++) 
    {
      struct Elf32_Phdr phdr;

      if (file_ofs < 0 || file_ofs > file_length (file)){
        //printf ("load: %s: 1\n", file_name);
        goto done;
      }
      file_seek (file, file_ofs);

      if (file_read (file, &phdr, sizeof phdr) != sizeof phdr){
        //printf ("load: %s: 2\n", file_name);
        goto done;
      }
      file_ofs += sizeof phdr;
      switch (phdr.p_type) 
        {
        case PT_NULL:
        case PT_NOTE:
        case PT_PHDR:
        case PT_STACK:
        default:
          /* Ignore this segment. */
          break;
        case PT_DYNAMIC:
        case PT_INTERP:
        case PT_SHLIB:
          goto done;
        case PT_LOAD:
          if (validate_segment (&phdr, file)) 
            {
              bool writable = (phdr.p_flags & PF_W) != 0;
              uint32_t file_page = phdr.p_offset & ~PGMASK;
              uint32_t mem_page = phdr.p_vaddr & ~PGMASK;
              uint32_t page_offset = phdr.p_vaddr & PGMASK;
              uint32_t read_bytes, zero_bytes;
              if (phdr.p_filesz > 0)
                {
                  /* Normal segment.
                     Read initial part from disk and zero the rest. */
                  read_bytes = page_offset + phdr.p_filesz;
                  zero_bytes = (ROUND_UP (page_offset + phdr.p_memsz, PGSIZE)
                                - read_bytes);
                }
              else 
                {
                  /* Entirely zero.
                     Don't read anything from disk. */
                  read_bytes = 0;
                  zero_bytes = ROUND_UP (page_offset + phdr.p_memsz, PGSIZE);
                }
              if (!load_segment (file, file_page, (void *) mem_page,
                                 read_bytes, zero_bytes, writable)){
                                  //printf ("load: %s: 3\n", file_name);
                goto done;
              }
            }
          else{
            //printf ("load: %s: 4\n", file_name);
            goto done;
          }
          break;
        }
    }

  /* Set up stack. */
  if (!setup_stack (esp))
    goto done;

  char* cmd_parsed[256]; //4kb
  char cmd_copy[256]; //4kb

  strlcpy(cmd_copy,file_name,strlen(file_name)+1);
  //printf("%c\n",cmd[1]);
  int cmd_num=get_arguments(cmd_copy,cmd_parsed);
  char* esp_copy=*esp;
  //printf("copy : %p, org : %p\n",esp_copy,*esp);
  //printf("parsing end. argc : %d\n",cmd_num);
  
  //명령어들부터 집어넣는다.
  //오른쪽 끝부터 먼저 들어간다.
  int tmp,cmd_length=0;
  for(int i=cmd_num-1; i>=0; i--){
    tmp=strlen(cmd_parsed[i])+1; //null문자 포함
    cmd_length+=tmp;
    *esp=*esp-tmp;
    strlcpy(*esp,cmd_parsed[i],tmp);
    //printf("address : %p | token : %s\n",*esp,cmd_parsed[i]);
  }

  //집어넣은 명령어의 총 길이가 4의 배수인지 확인한다(워드사이즈 32비트)
  *esp=*esp-4+(cmd_length%4);
  //printf("addresss : %p\n",*esp);

  //명령어들의 주소를 집어넣는다.
  //null문자부터 먼저 집어넣는다.
  *esp=*esp-4; 
  **(uint32_t **)esp=0;
  //printf("addresss : %p\n",*esp);

  //4개의 명령어의 주소값을 집어넣는다.
  for(int i=cmd_num-1; i>=0; i--){
    *esp=*esp-4;
    esp_copy-=( strlen(cmd_parsed[i]) + 1 );
    **(uint32_t **)esp=esp_copy;
    //printf("addresss : %p | data : %0x\n",*esp,**(uint32_t **)esp);
  }

    //argv배열의 주소값을 집어넣는다.
    *esp-=4;
    **(uint32_t**)esp=*esp+4;
    //printf("addresss : %p | data : %0x\n",*esp,**(uint32_t **)esp);

    //argc를 넣는다
    *esp-=4;
    **(uint32_t**)esp=cmd_num;
    //printf("addresss : %p | data : %d\n",*esp,**(uint32_t **)esp);

    //return address를 넣어준다.
    *esp-=4;
    **(uint32_t **)esp=0;
    //printf("addresss : %p\n",*esp);

    //hex_dump(*esp,*esp,100,1);
    //hex_dump(*esp,*esp,100,1);
  /* Start address. */
  *eip = (void (*) (void)) ehdr.e_entry;

  success = true;

 done:
  /* We arrive here whether the load is successful or not. */
  file_close (file);
  return success;
}

/* load() helpers. */

static bool install_page (void *upage, void *kpage, bool writable);

/* Checks whether PHDR describes a valid, loadable segment in
   FILE and returns true if so, false otherwise. */
static bool
validate_segment (const struct Elf32_Phdr *phdr, struct file *file) 
{
  /* p_offset and p_vaddr must have the same page offset. */
  if ((phdr->p_offset & PGMASK) != (phdr->p_vaddr & PGMASK)) 
    return false; 

  /* p_offset must point within FILE. */
  if (phdr->p_offset > (Elf32_Off) file_length (file)) 
    return false;

  /* p_memsz must be at least as big as p_filesz. */
  if (phdr->p_memsz < phdr->p_filesz) 
    return false; 

  /* The segment must not be empty. */
  if (phdr->p_memsz == 0)
    return false;
  
  /* The virtual memory region must both start and end within the
     user address space range. */
  if (!is_user_vaddr ((void *) phdr->p_vaddr))
    return false;
  if (!is_user_vaddr ((void *) (phdr->p_vaddr + phdr->p_memsz)))
    return false;

  /* The region cannot "wrap around" across the kernel virtual
     address space. */
  if (phdr->p_vaddr + phdr->p_memsz < phdr->p_vaddr)
    return false;

  /* Disallow mapping page 0.
     Not only is it a bad idea to map page 0, but if we allowed
     it then user code that passed a null pointer to system calls
     could quite likely panic the kernel by way of null pointer
     assertions in memcpy(), etc. */
  
  //!!여기 수정함!!//
  if (phdr->p_vaddr < PGSIZE) //원본
    return false;

  /* It's okay. */
  return true;
}

/* Loads a segment starting at offset OFS in FILE at address
   UPAGE.  In total, READ_BYTES + ZERO_BYTES bytes of virtual
   memory are initialized, as follows:

        - READ_BYTES bytes at UPAGE must be read from FILE
          starting at offset OFS.

        - ZERO_BYTES bytes at UPAGE + READ_BYTES must be zeroed.

   The pages initialized by this function must be writable by the
   user process if WRITABLE is true, read-only otherwise.

   Return true if successful, false if a memory allocation error
   or disk read error occurs. */
static bool
load_segment (struct file *file, off_t ofs, uint8_t *upage,
              uint32_t read_bytes, uint32_t zero_bytes, bool writable) 
{
  struct file* tmp=file_reopen(file);
  ASSERT ((read_bytes + zero_bytes) % PGSIZE == 0);
  ASSERT (pg_ofs (upage) == 0);
  ASSERT (ofs % PGSIZE == 0);
  file_seek (file, ofs);
  while (read_bytes > 0 || zero_bytes > 0) 
    {
      /* Calculate how to fill this page.
         We will read PAGE_READ_BYTES bytes from FILE
         and zero the final PAGE_ZERO_BYTES bytes. */
      size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
      size_t page_zero_bytes = PGSIZE - page_read_bytes;

      /*do not load to physical memory
      add all vaddr to supplemental page table, vm_hash*/
      struct page* pg=malloc(sizeof(struct page));
      pg->type=BIN;
      pg->vaddr=upage;
      pg->writable=writable;
      pg->is_loaded=false;
      pg->file_offset=ofs;
      //tmp로 다시 연 파일 넣어줘야 함. 그냥 file 넣으면 동일 파일에 대해 open 호출해서 에러 남.
      pg->file=tmp;
      pg->read_bytes=page_read_bytes;
      pg->zero_bytes=page_zero_bytes;
      //printf("offset : %d\n",vme->offset);
      //printf("load - upage : %p\n",upage);

      //add vm entry to vm table
      hash_insert(&thread_current()->vm_hash,&pg->helem);

      /* Advance. */
      read_bytes -= page_read_bytes;
      zero_bytes -= page_zero_bytes;
      /*prj4*/
      ofs+=page_read_bytes;
      upage += PGSIZE;
    }
  return true;
}

/* Create a minimal stack by mapping a zeroed page at the top of
   user virtual memory. */
static bool
setup_stack (void **esp) 
{
  struct frame *newframe;
  newframe=malloc(sizeof(struct frame));
  bool success = false;
  void *vaddr = ((uint8_t *) PHYS_BASE) - PGSIZE;

  void* kpage = palloc_get_page (PAL_USER | PAL_ZERO);
  newframe->physical_addr=kpage;
  if (kpage != NULL) 
    {
      success = install_page (((uint8_t *) PHYS_BASE) - PGSIZE, kpage, true);
      if (success)
        *esp = PHYS_BASE;
      else{
        printf("this exists?\n");
        palloc_free_page (kpage);
      }
    }
  /*add this stack's vaddr to vm table*/
  struct page* pg=malloc(sizeof(struct page));
  pg->type=SWAP;
  pg->vaddr=vaddr;
  pg->writable=true;
  pg->is_loaded=true;
  pg->read_bytes=0;
  pg->zero_bytes=PGSIZE;
  newframe->thr=thread_current();
  newframe->vme=pg;
  lock_acquire(&frame_lock);
  framelist_insert(&frame_list, newframe);
  lock_release(&frame_lock);
  hash_insert(&thread_current()->vm_hash,&pg->helem);
  //printf("stack's vaddr : %p %p\n",kpage,((uint8_t *) PHYS_BASE) - PGSIZE);
  return success;
}

/* Adds a mapping from user virtual address UPAGE to kernel
   virtual address KPAGE to the page table.
   If WRITABLE is true, the user process may modify the page;
   otherwise, it is read-only.
   UPAGE must not already be mapped.
   KPAGE should probably be a page obtained from the user pool
   with palloc_get_page().
   Returns true on success, false if UPAGE is already mapped or
   if memory allocation fails. */
static bool
install_page (void *upage, void *kpage, bool writable)
{
  struct thread *t = thread_current ();

  /* Verify that there's not already a page at that virtual
     address, then map our page there. */
  return (pagedir_get_page (t->pagedir, upage) == NULL
          && pagedir_set_page (t->pagedir, upage, kpage, writable));
}

bool stack_growth(void* vaddr){
  //try to get a new page
  void* new_frame=palloc_get_page(PAL_USER);

  //if user memory is full -> page replacement
  if(new_frame==NULL){
    lock_acquire(&frame_lock);
    page_replace(&frame_list);
    new_frame=palloc_get_page(PAL_USER);
  }

  //make struct page and add to frame_list
  struct frame* frame=malloc(sizeof(struct frame));
  frame->physical_addr=new_frame;
  frame->thr=thread_current();

  //create vm_entry
  struct page* pg=malloc(sizeof(struct page));
  pg->vaddr=vaddr;
  pg->is_loaded=true;
  pg->writable=true;

  bool flag_install_page=install_page(pg_round_down(pg->vaddr),new_frame,pg->writable);

  //put new page to page directory
  if(!flag_install_page){
    printf("failed flag_install_page");
    //free struct page
    //1. free current page
    palloc_free_page(frame->physical_addr);
    //2. remove current page from the frame_list
    //4. free struct page
    free(frame);
    free(pg);
    lock_release(&frame_lock);
    return false;
  

    //push new entry to vm_hash
    bool flag_insert_vme=vm_insert(&thread_current()->vm_hash,&pg->helem);
    if(!flag_insert_vme){
      printf("failed insert_vme");
      //free struct page
      //1. free current page
      palloc_free_page(frame->physical_addr);
      //2. remove current page from the frame_list
      //4. free struct page
      free(frame);
      free(pg);
      lock_release(&frame_lock);
      return false;
    }

    frame->vme=pg;
    //add page to frame_list
    framelist_insert(&frame_list, frame);
    //pagedir_set_accessed(page->thr->pagedir,page->vme->vaddr, true);
    lock_release(&frame_lock);
    return true;
  }
}

bool load_file_to_page(void* kaddr, struct page* pg){
      /* Load this page. */
      if (file_read_at (pg->file, kaddr, pg->read_bytes, pg->file_offset) != (int) pg->read_bytes)
        {
          palloc_free_page (kaddr);
          return false; 
        }
        //printf("%d\n",vme->read_bytes);
      memset (kaddr + pg->read_bytes, 0, pg->zero_bytes);
      //hex_dump(kaddr,kaddr,100,1);
      return true;
}

bool load_to_pmemory(void* vaddr, struct page* pg){
    //printf("load_to_pmemory\n");
    lock_acquire(&frame_lock);
    //proces's page -> get from user memory pool
    void* newframe=palloc_get_page(PAL_USER);
    int load_flag=false;
    //printf("newpage : %p  ||   page address: %p\n",newpage,pg_round_down(vme->vaddr));
    
    //if there was enough space
    if(newframe){
      //make struct page and add to frame_list(LRU)
      struct frame* frame=malloc(sizeof(struct frame));
      frame->physical_addr=newframe;
      frame->thr=thread_current();

      //load file to page

      //if BIN -> load from disk
      if(pg->type==BIN || pg->type==FILE_VM){
        //printf("here\n");
        load_flag=load_file_to_page(frame->physical_addr,pg);
        //printf("load result : %d\n",load_flag);
        if(!load_flag){
          //free struct page
          //1. free current page
          palloc_free_page(frame->physical_addr);
          //4. free struct page
          free(frame);
          lock_release(&frame_lock);
          return false;
        }        
      }

      else if(pg->type==SWAP){
        //printf("newpage-swapin\n");
        swap_in(pg->swapidx,frame->physical_addr);
      }

      //now add page to page directory
      bool flag;
      flag=install_page(pg->vaddr,newframe,pg->writable);
      if(!flag){
          printf("failed to create\n");
          //free struct page
          //1. free current page
          palloc_free_page(frame->physical_addr);
          //4. free struct page
          free(frame);
          lock_release(&frame_lock);
          return false;
      }

      //insert vme to page
      pg->is_loaded=true;
      frame->vme=pg;
      //add page to frame_list
      framelist_insert(&frame_list, frame);
      lock_release(&frame_lock);
      return true;
    }

    //no space left -> page replacement
    else{
      //printf("uu\n");
      //1. free some page
      page_replace(&frame_list);
      //printf("step 1 end\n");
      //2. get new page
      void* newframe_replaced=palloc_get_page(PAL_USER);
      
      //2. make struct page
      //printf("%d",thread_current()->tid);
      struct frame* frame=malloc(sizeof(struct frame));
      //printf("%d",thread_current()->tid);
      frame->thr=thread_current();
      //printf("newpage_replaced : %p\n",newpage_replaced);
      frame->physical_addr=newframe_replaced;
      pg->is_loaded=true;
      frame->vme=pg;
      
      //3. now add page to page directory
      bool flag;
      flag=install_page(pg->vaddr,frame->physical_addr,pg->writable);
      if(!flag){
          //printf("failed to create\n");
          //free struct page
          //1. free current page
          palloc_free_page(frame->physical_addr);
          //2. remove current page from the frame_list
          framelist_delete(&frame_list,frame);
          //4. free struct page
          free(frame);
          lock_release(&frame_lock);
          return false;
      }
      //add page to frame_list
      framelist_insert(&frame_list, frame);
      if(pg->type==BIN||pg->type==FILE_VM){
        //printf("trying to load\n");
        load_flag=load_file_to_page(frame->physical_addr,pg);
        //if(!load_flag) printf("sibal..\n");
      }
      else if(pg->type==SWAP){
        //printf("trying to swap-in\n");
        //printf("swap slot : %d\n",vme->swap_slot);
        swap_in(pg->swapidx,newframe_replaced);
        // for(int i=0; i<8; i++){
        //   printf("------------%dth----------------------\n",i);
        //   hex_dump(newpage_replaced+i*512,newpage_replaced+i*512,512,1);
        // }
      }
      lock_release(&frame_lock);
      return true;
    }
}
